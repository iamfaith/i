# coding=utf-8
from __future__ import absolute_import


class LayerExpression():

    expression = None
    groupIndex = 0
    type_countable = False

